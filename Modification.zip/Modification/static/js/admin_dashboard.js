// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventListeners();
});

function initializeDashboard() {
    console.log('Admin Dashboard initialized');
    // Any initialization code can go here
}

function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-item[data-target]').forEach(item => {
        item.addEventListener('click', function() {
            const target = this.getAttribute('data-target');
            if (target) {
                switchSection(target);
            }
        });
    });

    // Logout button
    document.getElementById('logoutBtn')?.addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            window.location.href = '/logout';
        }
    });

    // Decision modal buttons
    document.getElementById('confirmApprove')?.addEventListener('click', function() {
        submitDecision('approve');
    });

    document.getElementById('confirmReject')?.addEventListener('click', function() {
        submitDecision('reject');
    });

    // Academic Records Search Enter Key
    const studentSearch = document.getElementById('studentSearch');
    if (studentSearch) {
        studentSearch.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchStudent();
            }
        });
    }
}

function switchSection(sectionId) {
    // Update navigation
    document.querySelectorAll('.nav-item[data-target]').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-target="${sectionId}"]`).classList.add('active');

    // Update content sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');

    // Load data for specific sections if needed
    if (sectionId === 'approved-requests') {
        loadApprovedRequests();
    } else if (sectionId === 'rejected-requests') {
        loadRejectedRequests();
    } else if (sectionId === 'academic-records') {
        resetAcademicRecords();
    }
}

function resetAcademicRecords() {
    // Reset academic records section when switching to it
    document.getElementById('studentResults').style.display = 'none';
    document.getElementById('selectedStudentRecord').style.display = 'none';
    document.getElementById('noStudentSelected').style.display = 'block';
    document.getElementById('studentSearch').value = '';
    currentSelectedStudent = null;
}

function reviewRequest(requestId) {
    // Find the request data from the current page
    const requestElement = document.querySelector(`[onclick*="reviewRequest(${requestId})"]`)?.closest('.request-card');
    if (!requestElement) {
        showNotification('Request details not found', 'error');
        return;
    }

    try {
        // Extract data from the request element
        const studentInfo = requestElement.querySelector('.student-info h6').textContent.trim();
        const studentEmail = requestElement.querySelector('.student-info p.mb-1').textContent.trim();
        const requestType = requestElement.querySelector('.request-type').textContent.trim();
        const program = requestElement.querySelector('.student-info .text-end p:first-child').textContent.replace('Program:', '').trim();
        const moduleInfo = requestElement.querySelector('.detail-group:nth-child(2) p:first-child').textContent.trim();
        const reason = requestElement.querySelector('.detail-group:nth-child(2) p:last-child').textContent.replace('Reason for change:', '').trim();
        
        const lecturerApprovalElement = requestElement.querySelector('.detail-group:nth-child(3)');
        const lecturerApproval = lecturerApprovalElement ? lecturerApprovalElement.textContent.replace('Lecturer Approval', '').trim() : 'No lecturer approval';
        
        const hodRecommendationElement = requestElement.querySelector('.detail-group:nth-child(4)');
        const hodRecommendation = hodRecommendationElement ? hodRecommendationElement.textContent.replace('HOD Recommendation', '').trim() : 'No HOD recommendation';

        populateReviewModal({
            request_id: requestId,
            student_info: studentInfo,
            student_email: studentEmail,
            program: program,
            module_info: moduleInfo,
            request_type: requestType,
            reason: reason,
            lecturer_approval: lecturerApproval,
            hod_recommendation: hodRecommendation
        });
    } catch (error) {
        console.error('Error extracting request data:', error);
        showNotification('Error loading request details', 'error');
    }
}

function populateReviewModal(requestData) {
    const modalBody = document.getElementById('reviewModalBody');
    
    modalBody.innerHTML = `
        <div class="request-details-modal">
            <div class="detail-group">
                <h6>Student Information</h6>
                <p><strong>Student:</strong> ${requestData.student_info}</p>
                <p><strong>Email:</strong> ${requestData.student_email}</p>
                <p><strong>Program:</strong> ${requestData.program}</p>
            </div>
            
            <div class="detail-group">
                <h6>Module Information</h6>
                <p><strong>Module:</strong> ${requestData.module_info}</p>
                <p><strong>Request Type:</strong> <span class="request-type ${requestData.request_type.toLowerCase()}">${requestData.request_type}</span></p>
            </div>
            
            <div class="detail-group">
                <h6>Request Details</h6>
                <p><strong>Reason:</strong> ${requestData.reason || 'No reason provided'}</p>
            </div>
            
            <div class="detail-group">
                <h6>Approval Chain</h6>
                <div class="mb-2">
                    <strong>Lecturer Approval:</strong><br>
                    <span class="text-muted">${requestData.lecturer_approval || 'No lecturer approval'}</span>
                </div>
                <div>
                    <strong>HOD Recommendation:</strong><br>
                    <span class="text-muted">${requestData.hod_recommendation || 'No HOD recommendation'}</span>
                </div>
            </div>
            
            <div class="text-end mt-4">
                <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                <button class="btn btn-primary" onclick="openDecisionModal(${requestData.request_id}, '${requestData.student_info}', '${requestData.student_email}')">
                    <i class="fas fa-check-circle"></i> Make Final Decision
                </button>
            </div>
        </div>
    `;
    
    const modal = new bootstrap.Modal(document.getElementById('reviewModal'));
    modal.show();
}

function openDecisionModal(requestId, studentInfo, studentEmail) {
    // Close review modal first
    const reviewModal = bootstrap.Modal.getInstance(document.getElementById('reviewModal'));
    if (reviewModal) {
        reviewModal.hide();
    }

    currentRequestId = requestId;
    
    document.getElementById('modalRequestDetails').innerHTML = `
        <div class="alert alert-info">
            <h6>Request #${requestId}</h6>
            <p class="mb-1"><strong>Student:</strong> ${studentInfo}</p>
            <p class="mb-0"><strong>Email:</strong> ${studentEmail}</p>
        </div>
    `;
    
    // Reset form
    document.getElementById('adminComments').value = '';
    
    const modal = new bootstrap.Modal(document.getElementById('decisionModal'));
    modal.show();
}

function makeDecision(requestId, decision) {
    currentRequestId = requestId;
    currentDecision = decision;
    
    const modal = new bootstrap.Modal(document.getElementById('decisionModal'));
    const requestElement = document.querySelector(`[onclick*="makeDecision(${requestId},"]`)?.closest('.request-card');
    
    if (requestElement) {
        const studentInfo = requestElement.querySelector('.student-info h6').textContent;
        const studentEmail = requestElement.querySelector('.student-info p.mb-1').textContent;
        
        document.getElementById('modalRequestDetails').innerHTML = `
            <div class="alert alert-info">
                <h6>Request #${requestId}</h6>
                <p class="mb-1"><strong>Student:</strong> ${studentInfo}</p>
                <p class="mb-0"><strong>Email:</strong> ${studentEmail}</p>
                <p class="mb-0 mt-2">You are about to <strong>${decision}</strong> this module modification request.</p>
            </div>
        `;
        
        // Reset form
        document.getElementById('adminComments').value = '';
        
        modal.show();
    } else {
        showNotification('Request details not found', 'error');
    }
}

async function submitDecision(decision) {
    if (!currentRequestId) {
        showNotification('No request selected', 'error');
        return;
    }

    const comments = document.getElementById('adminComments').value.trim();
    if (!comments) {
        showNotification('Please provide administrative comments.', 'error');
        return;
    }

    const endpoint = decision === 'approve' 
        ? `/admin/approve-request/${currentRequestId}`
        : `/admin/reject-request/${currentRequestId}`;

    try {
        showNotification('Submitting decision...', 'info');
        
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                comment: comments
            })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showNotification(`Request ${decision === 'approve' ? 'approved' : 'rejected'} successfully!`, 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('decisionModal'));
            if (modal) {
                modal.hide();
            }
            
            // Refresh the page after a short delay
            setTimeout(() => {
                location.reload();
            }, 2000);
        } else {
            showNotification('Error: ' + (result.error || 'Failed to submit decision'), 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('Error submitting decision: ' + error.message, 'error');
    }
}

async function loadApprovedRequests() {
    try {
        // This would typically fetch from an API endpoint
        console.log('Loading approved requests...');
        // For now, we'll just show the empty state
    } catch (error) {
        console.error('Error loading approved requests:', error);
        showNotification('Error loading approved requests', 'error');
    }
}

async function loadRejectedRequests() {
    try {
        // This would typically fetch from an API endpoint
        console.log('Loading rejected requests...');
        // For now, we'll just show the empty state
    } catch (error) {
        console.error('Error loading rejected requests:', error);
        showNotification('Error loading rejected requests', 'error');
    }
}

// Utility function to show notifications
function showNotification(message, type = 'info') {
    // Remove any existing notifications
    const existingNotifications = document.querySelectorAll('.custom-notification');
    existingNotifications.forEach(notification => notification.remove());

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `custom-notification alert alert-${type === 'success' ? 'success' : type === 'error' ? 'danger' : 'info'} alert-dismissible fade show`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    `;
    
    notification.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
            <span>${message}</span>
            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Global variables
let currentRequestId = null;
let currentDecision = null;

// =============================================================================
// ACADEMIC RECORDS JAVASCRIPT
// =============================================================================

let currentSelectedStudent = null;

function searchStudent() {
    const searchTerm = document.getElementById('studentSearch').value.trim();
    const programFilter = document.getElementById('programFilter').value;
    
    if (!searchTerm) {
        alert('Please enter a search term');
        return;
    }

    // Show loading state
    const studentList = document.getElementById('studentList');
    studentList.innerHTML = '<div class="list-group-item text-center text-muted"><i class="fas fa-spinner fa-spin me-2"></i>Searching...</div>';
    document.getElementById('studentResults').style.display = 'block';

    fetch(`/api/admin/search-students?q=${encodeURIComponent(searchTerm)}&program=${programFilter}`)
        .then(response => response.json())
        .then(data => {
            studentList.innerHTML = '';

            if (data.students && data.students.length > 0) {
                data.students.forEach(student => {
                    const studentItem = document.createElement('button');
                    studentItem.type = 'button';
                    studentItem.className = 'list-group-item list-group-item-action';
                    studentItem.innerHTML = `
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">${student.username} - ${student.first_name} ${student.last_name}</h6>
                            <small class="text-muted">${student.program_code}</small>
                        </div>
                        <p class="mb-1 text-muted">${student.email}</p>
                        <small class="text-muted">Year ${student.year_level} - ${student.enrollment_status}</small>
                    `;
                    studentItem.onclick = () => selectStudent(student);
                    studentList.appendChild(studentItem);
                });
            } else {
                studentList.innerHTML = '<div class="list-group-item text-center text-muted"><i class="fas fa-search me-2"></i>No students found</div>';
            }
        })
        .catch(error => {
            console.error('Error searching students:', error);
            studentList.innerHTML = '<div class="list-group-item text-center text-danger"><i class="fas fa-exclamation-circle me-2"></i>Error searching students</div>';
        });
}

function filterByProgram() {
    // Trigger search again when program filter changes
    if (document.getElementById('studentSearch').value.trim()) {
        searchStudent();
    }
}

function selectStudent(student) {
    currentSelectedStudent = student;
    
    // Hide search results and show student record
    document.getElementById('studentResults').style.display = 'none';
    document.getElementById('noStudentSelected').style.display = 'none';
    document.getElementById('selectedStudentRecord').style.display = 'block';

    // Update student info
    document.getElementById('studentInfoHeader').textContent = `Student Information - ${student.username}`;
    document.getElementById('studentInfo').innerHTML = `
        <div class="col-md-6">
            <p><strong>Name:</strong> ${student.first_name} ${student.last_name}</p>
            <p><strong>Email:</strong> ${student.email}</p>
            <p><strong>Program:</strong> ${student.program_code}</p>
        </div>
        <div class="col-md-6">
            <p><strong>Year Level:</strong> ${student.year_level}</p>
            <p><strong>Status:</strong> <span class="badge bg-success">${student.enrollment_status}</span></p>
            <p><strong>Total Credits:</strong> ${student.total_credits_earned || 0}</p>
        </div>
    `;

    // Load academic data
    loadStudentAcademicData(student.username);
}

function loadStudentAcademicData(username) {
    // Show loading states
    document.getElementById('currentEnrollments').innerHTML = '<div class="text-center py-3"><i class="fas fa-spinner fa-spin me-2"></i>Loading enrollments...</div>';
    document.getElementById('academicHistoryTable').innerHTML = '<tr><td colspan="8" class="text-center py-3"><i class="fas fa-spinner fa-spin me-2"></i>Loading academic history...</td></tr>';
    
    // Reset statistics
    document.getElementById('totalCredits').textContent = '0';
    document.getElementById('completedModules').textContent = '0';
    document.getElementById('failedModules').textContent = '0';

    // Load current enrollments
    fetch(`/api/admin/student-enrollments/${username}`)
        .then(response => response.json())
        .then(data => {
            const enrollmentsContainer = document.getElementById('currentEnrollments');
            if (data.enrollments && data.enrollments.length > 0) {
                let html = `
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Module Code</th>
                                    <th>Module Name</th>
                                    <th>Credits</th>
                                    <th>Department</th>
                                    <th>Year Level</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                data.enrollments.forEach(module => {
                    html += `
                        <tr>
                            <td><strong>${module.module_code}</strong></td>
                            <td>${module.module_name}</td>
                            <td>${module.credits}</td>
                            <td>${module.department}</td>
                            <td>Year ${module.year_level}</td>
                        </tr>
                    `;
                });
                html += `</tbody></table></div>`;
                enrollmentsContainer.innerHTML = html;
            } else {
                enrollmentsContainer.innerHTML = '<div class="text-center py-4"><i class="fas fa-book-open fa-2x text-muted mb-3"></i><p class="text-muted">No current enrollments</p></div>';
            }
        })
        .catch(error => {
            console.error('Error loading enrollments:', error);
            document.getElementById('currentEnrollments').innerHTML = '<div class="text-center py-4 text-danger"><i class="fas fa-exclamation-circle fa-2x mb-3"></i><p>Error loading enrollments</p></div>';
        });

    // Load academic history
    fetch(`/api/admin/student-academic-history/${username}`)
        .then(response => response.json())
        .then(data => {
            const historyTable = document.getElementById('academicHistoryTable');
            if (data.history && data.history.length > 0) {
                let html = '';
                data.history.forEach(record => {
                    const statusClass = record.status === 'Completed' ? 'table-success' : 
                                     record.status === 'Failed' ? 'table-danger' : 'table-warning';
                    const statusBadge = record.status === 'Completed' ? 'bg-success' : 
                                      record.status === 'Failed' ? 'bg-danger' : 'bg-warning';
                    
                    html += `
                        <tr class="${statusClass}">
                            <td>${record.academic_year}</td>
                            <td>Semester ${record.semester}</td>
                            <td><strong>${record.module_code}</strong></td>
                            <td>${record.module_name}</td>
                            <td>${record.final_mark || 'N/A'}</td>
                            <td><span class="badge ${statusBadge}">${record.grade || 'N/A'}</span></td>
                            <td>${record.credits_earned}</td>
                            <td>
                                <span class="badge ${statusBadge}">
                                    ${record.status}
                                </span>
                            </td>
                        </tr>
                    `;
                });
                historyTable.innerHTML = html;

                // Update statistics
                document.getElementById('totalCredits').textContent = data.total_credits || 0;
                document.getElementById('completedModules').textContent = data.completed_modules || 0;
                document.getElementById('failedModules').textContent = data.failed_modules || 0;
            } else {
                historyTable.innerHTML = '<tr><td colspan="8" class="text-center py-4 text-muted"><i class="fas fa-graduation-cap fa-2x mb-3"></i><p>No academic history found</p></td></tr>';
            }
        })
        .catch(error => {
            console.error('Error loading academic history:', error);
            document.getElementById('academicHistoryTable').innerHTML = '<tr><td colspan="8" class="text-center py-4 text-danger"><i class="fas fa-exclamation-circle fa-2x mb-3"></i><p>Error loading academic history</p></td></tr>';
        });
}