// Student Dashboard JavaScript - Working Version
document.addEventListener('DOMContentLoaded', function() {
    console.log('Student Dashboard initialized');
    
    // Navigation
    const navItems = document.querySelectorAll('.nav-item');
    const contentSections = document.querySelectorAll('.content-section');
    
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            if (this.id === 'logoutBtn') {
                logout();
                return;
            }
            
            // Remove active class from all items
            navItems.forEach(nav => nav.classList.remove('active'));
            contentSections.forEach(section => section.classList.remove('active'));
            
            // Add active class to clicked item
            this.classList.add('active');
            
            // Show corresponding section
            const target = this.getAttribute('data-target');
            const targetSection = document.getElementById(target);
            if (targetSection) {
                targetSection.classList.add('active');
            }
        });
    });
    
    // Tab Navigation
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Remove active class from all tabs and contents
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            this.classList.add('active');
            const targetContent = document.getElementById(tabId);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
    
    // Add Module Row buttons
    const addModuleRowBtn = document.getElementById('addModuleRow');
    if (addModuleRowBtn) {
        addModuleRowBtn.addEventListener('click', function() {
            addModuleRow('add');
        });
    }
    
    const addCancelRowBtn = document.getElementById('addCancelRow');
    if (addCancelRowBtn) {
        addCancelRowBtn.addEventListener('click', function() {
            addModuleRow('cancel');
        });
    }
    
    // Form Submissions
    const addModuleForm = document.getElementById('addModuleForm');
    if (addModuleForm) {
        addModuleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitRequest('add');
        });
    }
    
    const cancelModuleForm = document.getElementById('cancelModuleForm');
    if (cancelModuleForm) {
        cancelModuleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitRequest('cancel');
        });
    }
    
    // Alert Close Buttons
    document.querySelectorAll('.close-alert').forEach(button => {
        button.addEventListener('click', function() {
            this.parentElement.style.display = 'none';
        });
    });
    
    // Simple Chatbot Functionality
    const chatbotButton = document.getElementById('chatbotButton');
    const chatbotWindow = document.getElementById('chatbotWindow');
    const chatbotClose = document.getElementById('chatbotClose');
    
    if (chatbotButton && chatbotWindow) {
        chatbotButton.addEventListener('click', function() {
            chatbotWindow.classList.toggle('active');
        });
    }
    
    if (chatbotClose && chatbotWindow) {
        chatbotClose.addEventListener('click', function() {
            chatbotWindow.classList.remove('active');
        });
    }
    
    // Chatbot message handling
    const chatbotSend = document.getElementById('chatbotSend');
    const chatbotInput = document.getElementById('chatbotInput');
    const chatbotMessages = document.getElementById('chatbotMessages');
    
    if (chatbotSend && chatbotInput && chatbotMessages) {
        chatbotSend.addEventListener('click', sendChatbotMessage);
        chatbotInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendChatbotMessage();
            }
        });
    }
    
    // Initialize any existing request details buttons
    initializeRequestDetailsButtons();
    
    // Load academic history on page load
    loadAcademicHistory();
});

// Academic History Loading Function - ADDED WITHOUT MODIFYING EXISTING CODE
async function loadAcademicHistory() {
    try {
        const res = await fetch('/api/student/academic-history', { credentials: 'same-origin' });
        if (!res.ok) throw new Error('Failed to load academic history');
        const data = await res.json();
        const container = document.getElementById('academicHistory');
        if (!container) return;
        const records = (data.records && data.records.length) ? data.records : [];
        if (!records.length) {
            container.innerHTML = '<div class="empty">No academic records found.</div>';
            return;
        }
        container.innerHTML = records.map(r => `
            <div class="record-row">
                <div class="code">${r.module_code}</div>
                <div class="name">${r.module_name || ''}</div>
                <div class="year">${r.academic_year || ''} S${r.semester || ''}</div>
                <div class="grade">${r.grade || ''}</div>
                <div class="status">${r.status || ''}</div>
                <div class="credits">${r.credits_earned || 0}</div>
            </div>
        `).join('');
    } catch (e) {
        console.error('loadAcademicHistory error:', e);
    }
}

// Add Module Row Function
function addModuleRow(type) {
    const container = document.getElementById(`${type}ModuleRows`);
    if (!container) {
        console.error(`Container not found for type: ${type}`);
        return;
    }
    
    const rowCount = container.children.length + 1;
    
    const row = document.createElement('div');
    row.className = 'module-row';
    row.setAttribute('data-row', rowCount);
    
    row.innerHTML = `
        <div class="form-row">
            <div class="form-group form-col">
                <label class="form-label">Module Code</label>
                <input type="text" class="form-input module-code" placeholder="e.g., 4CPS111" required>
            </div>
            
            <div class="form-group form-col">
                <label class="form-label">Module Name</label>
                <input type="text" class="form-input module-name" placeholder="e.g., Introductory Computing" required>
            </div>
            
            <div class="form-group form-col">
                <label class="form-label">Semester</label>
                <select class="form-select module-semester" required>
                    <option value="">Select Semester</option>
                    <option value="1">Semester 1</option>
                    <option value="2">Semester 2</option>
                </select>
            </div>
            
            <div class="form-group form-col-auto">
                <label class="form-label">&nbsp;</label>
                <button type="button" class="remove-row-btn" onclick="removeModuleRow(this, '${type}')">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;
    
    container.appendChild(row);
}

// Remove Module Row Function
function removeModuleRow(button, type) {
    const container = document.getElementById(`${type}ModuleRows`);
    if (!container) return;
    
    const row = button.closest('.module-row');
    
    if (container.children.length > 1) {
        row.remove();
    } else {
        showAlert('You need at least one module row.', 'error');
    }
}

// Submit Request Function
async function submitRequest(type) {
    const loadingSpinner = document.getElementById('loadingSpinner');
    const form = document.getElementById(`${type}ModuleForm`);
    const reasonField = document.getElementById(`${type}Reason`);
    
    if (!form || !reasonField) {
        showAlert('Form elements not found. Please refresh the page.', 'error');
        return;
    }
    
    // Validate form
    if (!validateForm(type)) {
        showAlert('Please fill in all required fields correctly.', 'error');
        return;
    }
    
    // Show loading spinner
    if (loadingSpinner) loadingSpinner.classList.add('active');
    
    try {
        // Collect module data
        const modules = [];
        const moduleRows = document.querySelectorAll(`#${type}ModuleRows .module-row`);
        
        moduleRows.forEach(row => {
            const moduleCode = row.querySelector('.module-code').value.trim();
            const moduleName = row.querySelector('.module-name').value.trim();
            const semester = row.querySelector('.module-semester').value;
            
            modules.push({
                module_code: moduleCode,
                module_name: moduleName,
                semester: semester
            });
        });
        
        // Prepare request data
        const requestData = {
            request_type: type,
            reason: reasonField.value.trim(),
            modules: modules
        };
        
        console.log('Submitting request:', requestData);
        
        // Make API call to Flask backend
        const response = await fetch('/student/submit-request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(requestData)
        });
        
        const result = await response.json();
        
        // Hide loading spinner
        if (loadingSpinner) loadingSpinner.classList.remove('active');
        
        if (result.success) {
            showAlert(result.message, 'success');
            
            // Reset form
            form.reset();
            
            // Reset to single row
            const container = document.getElementById(`${type}ModuleRows`);
            if (container) {
                while (container.children.length > 1) {
                    container.removeChild(container.lastChild);
                }
            }
            
        } else {
            showAlert(result.error || 'Failed to submit request. Please try again.', 'error');
        }
        
    } catch (error) {
        if (loadingSpinner) loadingSpinner.classList.remove('active');
        showAlert('Network error. Please check your connection and try again.', 'error');
        console.error('Error submitting request:', error);
    }
}

// Form Validation Function
function validateForm(type) {
    const moduleRows = document.querySelectorAll(`#${type}ModuleRows .module-row`);
    const reasonField = document.getElementById(`${type}Reason`);
    
    // Check if at least one module is added
    if (moduleRows.length === 0) {
        return false;
    }
    
    // Validate each module row
    let isValid = true;
    moduleRows.forEach(row => {
        const moduleCode = row.querySelector('.module-code');
        const moduleName = row.querySelector('.module-name');
        const semester = row.querySelector('.module-semester');
        
        if (!moduleCode || !moduleName || !semester) return;
        
        if (!moduleCode.value.trim() || !moduleName.value.trim() || !semester.value) {
            isValid = false;
            // Highlight empty fields
            if (!moduleCode.value.trim()) moduleCode.classList.add('error');
            if (!moduleName.value.trim()) moduleName.classList.add('error');
            if (!semester.value) semester.classList.add('error');
        } else {
            // Remove error highlighting
            moduleCode.classList.remove('error');
            moduleName.classList.remove('error');
            semester.classList.remove('error');
        }
    });
    
    // Validate reason field
    if (!reasonField || !reasonField.value.trim()) {
        if (reasonField) reasonField.classList.add('error');
        isValid = false;
    } else {
        if (reasonField) reasonField.classList.remove('error');
    }
    
    return isValid;
}

// Initialize Request Details Buttons
function initializeRequestDetailsButtons() {
    // Add click handlers to all existing "Details" buttons
    document.addEventListener('click', function(e) {
        if (e.target.closest('.btn-info') || e.target.closest('[onclick*="viewRequestDetails"]')) {
            e.preventDefault();
            const button = e.target.closest('button');
            if (button) {
                // Extract request ID from onclick attribute or data attribute
                const onclick = button.getAttribute('onclick');
                if (onclick && onclick.includes('viewRequestDetails')) {
                    const match = onclick.match(/viewRequestDetails\((\d+)\)/);
                    if (match && match[1]) {
                        const requestId = parseInt(match[1]);
                        viewRequestDetails(requestId);
                    }
                }
            }
        }
    });
}

// Simple View Request Details Function
function viewRequestDetails(requestId) {
    console.log('Viewing details for request:', requestId);
    
    // Find the request row in the table
    const rows = document.querySelectorAll('#track-status tbody tr');
    let requestData = null;
    
    for (let row of rows) {
        const firstCell = row.querySelector('td:first-child');
        if (firstCell && firstCell.textContent.includes('#' + requestId)) {
            const cells = row.querySelectorAll('td');
            requestData = {
                request_id: requestId,
                module_code: cells[1]?.textContent || 'N/A',
                module_name: cells[2]?.textContent || 'N/A',
                request_type: cells[3]?.textContent.toLowerCase().trim() || 'N/A',
                status: getStatusFromClass(cells[4]?.querySelector('.status-badge')),
                date: cells[5]?.textContent || 'N/A'
            };
            break;
        }
    }
    
    if (requestData) {
        showRequestDetailsModal(requestData);
    } else {
        showAlert('Request details not found.', 'error');
    }
}

// Helper function to extract status from class
function getStatusFromClass(statusElement) {
    if (!statusElement) return 'unknown';
    
    const className = statusElement.className;
    if (className.includes('pending')) return 'pending';
    if (className.includes('approved')) return 'approved';
    if (className.includes('rejected')) return 'rejected';
    
    return 'unknown';
}

// Show Request Details in Modal
function showRequestDetailsModal(request) {
    // Create simple modal HTML
    const modalHTML = `
        <div class="modal" id="simpleRequestModal" style="display: block; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5);">
            <div class="modal-content" style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px; border-radius: 8px;">
                <div class="modal-header" style="display: flex; justify-content: between; align-items: center; border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 20px;">
                    <h3 style="margin: 0;">Request Details #${request.request_id}</h3>
                    <button class="close-modal" style="background: none; border: none; font-size: 24px; cursor: pointer;">&times;</button>
                </div>
                <div class="modal-body">
                    <div style="display: grid; gap: 15px;">
                        <div>
                            <strong>Module Code:</strong> ${request.module_code}
                        </div>
                        <div>
                            <strong>Module Name:</strong> ${request.module_name}
                        </div>
                        <div>
                            <strong>Request Type:</strong> 
                            <span style="padding: 4px 8px; border-radius: 4px; background: ${request.request_type === 'add' ? '#d4edda' : '#fff3cd'}; color: ${request.request_type === 'add' ? '#155724' : '#856404'};">
                                ${request.request_type}
                            </span>
                        </div>
                        <div>
                            <strong>Status:</strong>
                            <span style="padding: 4px 8px; border-radius: 4px; background: ${getStatusColor(request.status)}; color: white;">
                                ${request.status}
                            </span>
                        </div>
                        <div>
                            <strong>Date Submitted:</strong> ${request.date}
                        </div>
                    </div>
                    <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 4px;">
                        <p style="margin: 0; color: #666; font-style: italic;">
                            Detailed approval progress and comments will be available once the request starts processing.
                        </p>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #ddd; padding-top: 15px; margin-top: 20px; text-align: right;">
                    <button class="btn btn-secondary close-modal" style="padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer;">Close</button>
                </div>
            </div>
        </div>
    `;
    
    // Remove any existing modal
    const existingModal = document.getElementById('simpleRequestModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add modal to page
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listeners to close buttons
    document.querySelectorAll('#simpleRequestModal .close-modal').forEach(button => {
        button.addEventListener('click', function() {
            const modal = document.getElementById('simpleRequestModal');
            if (modal) {
                modal.remove();
            }
        });
    });
    
    // Close modal when clicking outside
    document.getElementById('simpleRequestModal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.remove();
        }
    });
}

// Helper function for status colors
function getStatusColor(status) {
    const colors = {
        'pending': '#ffc107',
        'approved': '#28a745',
        'rejected': '#dc3545',
        'unknown': '#6c757d'
    };
    return colors[status] || '#6c757d';
}

// Show Alert Function
function showAlert(message, type) {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => {
        if (alert.parentElement) {
            alert.remove();
        }
    });
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="close-alert">&times;</button>
    `;
    
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        // Insert after welcome banner or at the top
        const welcomeBanner = document.querySelector('.welcome-banner');
        if (welcomeBanner && welcomeBanner.nextSibling) {
            mainContent.insertBefore(alertDiv, welcomeBanner.nextSibling);
        } else {
            mainContent.insertBefore(alertDiv, mainContent.firstChild);
        }
        
        // Add event listener to close button
        const closeBtn = alertDiv.querySelector('.close-alert');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                alertDiv.remove();
            });
        }
        
        // Auto remove after 5 seconds for success messages
        if (type === 'success') {
            setTimeout(() => {
                if (alertDiv.parentElement) {
                    alertDiv.remove();
                }
            }, 5000);
        }
    }
}

// Logout Function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // Show loading spinner
        const loadingSpinner = document.getElementById('loadingSpinner');
        if (loadingSpinner) loadingSpinner.classList.add('active');
        
        // Perform logout
        fetch('/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        })
        .then(response => response.json())
        .then(data => {
            if (loadingSpinner) loadingSpinner.classList.remove('active');
            if (data.success) {
                window.location.href = data.redirect || '/login';
            } else {
                showAlert('Logout failed. Please try again.', 'error');
            }
        })
        .catch(error => {
            console.error('Logout error:', error);
            if (loadingSpinner) loadingSpinner.classList.remove('active');
            showAlert('Logout failed. Please try again.', 'error');
        });
    }
}

// Chatbot Functions
function sendChatbotMessage() {
    const message = chatbotInput.value.trim();
    if (message) {
        // Add user message
        addChatMessage(message, 'user');
        chatbotInput.value = '';
        
        // Simulate bot response
        setTimeout(() => {
            const response = generateBotResponse(message);
            addChatMessage(response, 'bot');
        }, 1000);
    }
}

function addChatMessage(message, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.textContent = message;
    chatbotMessages.appendChild(messageDiv);
    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

// Enhanced Bot Response Function
function generateBotResponse(message) {
    const lowerMessage = message.toLowerCase();

    if (
        lowerMessage.includes('hi') ||
        lowerMessage.includes('hello') ||
        lowerMessage.includes('hey')
    ) {
        return "Hello there! How can I help you with your module modifications today?";
    } else if (lowerMessage.includes('module') && lowerMessage.includes('add')) {
        return "To add a module, go to the 'New Request' section and select 'Add Module'. Fill in the module details and submit your request.";
    } else if (lowerMessage.includes('module') && lowerMessage.includes('cancel')) {
        return "To cancel a module, go to the 'New Request' section and select 'Cancel Module'. Provide the module details and reason for cancellation.";
    } else if (lowerMessage.includes('status') || lowerMessage.includes('track')) {
        return "You can check the status of your requests in the 'Request Status' section. It shows all your previous requests and their current status.";
    } else if (lowerMessage.includes('academic') || lowerMessage.includes('record')) {
        return "Your complete academic record is available in the 'Academic Record' section. It shows all your modules, grades, and academic performance.";
    } else if (lowerMessage.includes('help')) {
        return "I can help you with adding or canceling modules, checking request status, viewing academic records, or general navigation. What do you need help with?";
    } else {
        return "Got it - you are asking about '" + message + "'. What would you like to do with your module modifications?";
    }
}

// Export functions for global access
window.addModuleRow = addModuleRow;
window.removeModuleRow = removeModuleRow;
window.submitRequest = submitRequest;
window.viewRequestDetails = viewRequestDetails;
window.showAlert = showAlert;
window.logout = logout;
window.sendChatbotMessage = sendChatbotMessage;
window.generateBotResponse = generateBotResponse;
window.loadAcademicHistory = loadAcademicHistory;