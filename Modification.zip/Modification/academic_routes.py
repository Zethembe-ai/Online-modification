"""
STANDALONE ACADEMIC ROUTES
Add this as a separate routes file
"""

from flask import Blueprint, jsonify, request
from academic_records import complete_module_automatic, get_student_transcript, get_failed_modules

# Create blueprint for academic routes
academic_bp = Blueprint('academic', __name__)

@academic_bp.route('/api/student/<username>/complete-module', methods=['POST'])
def api_complete_module(username):
    """
    API endpoint to complete a module
    POST body: {"module_code": "4CPS312", "final_mark": 78}
    """
    data = request.json
    result = complete_module_automatic(
        username=username,
        module_code=data['module_code'],
        final_mark=data['final_mark'],
        semester=data.get('semester'),
        academic_year=data.get('academic_year')
    )
    return jsonify(result)

@academic_bp.route('/api/student/<username>/transcript')
def api_student_transcript(username):
    """Get student's complete academic transcript"""
    result = get_student_transcript(username)
    return jsonify(result)

@academic_bp.route('/api/student/<username>/failed-modules')
def api_failed_modules(username):
    """Get student's failed modules"""
    result = get_failed_modules(username)
    return jsonify(result)

@academic_bp.route('/api/admin/batch-complete-modules', methods=['POST'])
def api_batch_complete():
    """
    Batch complete multiple modules
    POST body: {
        "completions": [
            {"username": "202300001", "module_code": "4CPS312", "final_mark": 78},
            {"username": "202300002", "module_code": "4MTH312", "final_mark": 65}
        ]
    }
    """
    data = request.json
    results = []
    
    for completion in data['completions']:
        result = complete_module_automatic(
            username=completion['username'],
            module_code=completion['module_code'],
            final_mark=completion['final_mark'],
            semester=completion.get('semester'),
            academic_year=completion.get('academic_year')
        )
        results.append(result)
    
    return jsonify({
        'success': True,
        'total': len(results),
        'results': results
    })