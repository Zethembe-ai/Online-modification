from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message
import sqlite3
import json
import os
import smtplib
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'unizulu-modification-system-2024-secret-key'

# Email configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'noreply.unizulu@gmail.com'
app.config['MAIL_PASSWORD'] = 'your-app-password-here'
app.config['MAIL_DEFAULT_SENDER'] = 'noreply.unizulu@gmail.com'

# ============================================================================
# ACADEMIC RECORDS INTEGRATION
# ============================================================================

from academic_routes import academic_bp
app.register_blueprint(academic_bp)

mail = Mail(app)
current_semester = 2  # Example: second semester

# Academic Records System Class
class AcademicRecordsSystem:
    def __init__(self, db_path):
        self.db_path = db_path
    
    def get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def get_student_academic_history(self, username):
        """Get complete academic history for a student"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        try:
            # First try academic_records table (if it exists)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='academic_records'")
            academic_records_exists = cursor.fetchone()
            
            if academic_records_exists:
                cursor.execute('''
                    SELECT username, module_code, module_name, final_mark, grade, credits_earned, 
                           status, academic_year, semester, completed_at
                    FROM academic_records 
                    WHERE username = ? 
                    ORDER BY academic_year DESC, semester DESC
                ''', (username,))
            else:
                # Fallback to student_modules table
                cursor.execute('''
                    SELECT username, module_code, module_name, final_mark, grade, credits_earned, 
                           status, academic_year, semester, NULL as completed_at
                    FROM student_modules 
                    WHERE username = ? 
                    ORDER BY academic_year DESC, semester DESC
                ''', (username,))
            
            records = [dict(row) for row in cursor.fetchall()]
            return records
            
        except Exception as e:
            print(f"Error getting academic history: {e}")
            return []
        finally:
            conn.close()

# Initialize the academic records system
AR = AcademicRecordsSystem('database.db')

def handle_module_request(student_id, module_code, action):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT semester FROM modules WHERE module_code = ?", (module_code,))
        result = cursor.fetchone()

        if not result:
            conn.close()
            return "Module not found."

        module_semester = result[0]

        # Rule: only current-semester modules can be added
        if action.lower() == "add" and module_semester != current_semester:
            conn.close()
            return "You can only add modules from the current semester."

        # Rule: allow cancellation of any enrolled module
        if action.lower() == "cancel":
            cursor.execute("""
                DELETE FROM student_modules 
                WHERE student_id = ? AND module_code = ?
            """, (student_id, module_code))
            conn.commit()
            conn.close()
            return "Module cancelled successfully."

        # If valid add request
        if action.lower() == "add":
            cursor.execute("""
                INSERT INTO modification_requests (student_id, module_code, status)
                VALUES (?, ?, 'Pending')
            """, (student_id, module_code))
            conn.commit()
            conn.close()
            return "Module added successfully."

        conn.close()
        return "Invalid action."
    except Exception as e:
        print(f"Error in handle_module_request: {e}")
        return f"Error: {str(e)}"

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

class User(UserMixin):
    def __init__(self, id, username, role, email, name, **kwargs):
        self.id = id
        self.username = username
        self.role = role
        self.email = email
        self.name = name
        for key, value in kwargs.items():
            setattr(self, key, value)

@login_manager.user_loader
def load_user(user_id):
    try:
        role, username = user_id.split(':', 1)
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if role == 'student':
            cursor.execute('''
                SELECT username, email, first_name, last_name, program_code, year_level 
                FROM students WHERE username = ?
            ''', (username,))
            user_data = cursor.fetchone()
            if user_data:
                user = User(
                    f"student:{username}", 
                    username, 
                    'student', 
                    user_data[1], 
                    f"{user_data[2]} {user_data[3]}",
                    program_code=user_data[4],
                    year_level=user_data[5]
                )
                conn.close()
                return user
        
        elif role == 'lecturer':
            cursor.execute('''
                SELECT username, email, title, last_name, department, faculty
                FROM lecturers WHERE username = ?
            ''', (username,))
            user_data = cursor.fetchone()
            if user_data:
                name = f"{user_data[2]} {user_data[3]}".strip()
                user = User(
                    f"lecturer:{username}", 
                    username, 
                    'lecturer', 
                    user_data[1], 
                    name,
                    title=user_data[2],
                    last_name=user_data[3],
                    department=user_data[4],
                    faculty=user_data[5]
                )
                conn.close()
                return user
        
        elif role == 'hod':
            cursor.execute('''
                SELECT username, email, title, last_name, department, faculty
                FROM hods WHERE username = ?
            ''', (username,))
            user_data = cursor.fetchone()
            if user_data:
                name = f"{user_data[2]} {user_data[3]}".strip()
                user = User(
                    f"hod:{username}", 
                    username, 
                    'hod', 
                    user_data[1], 
                    name,
                    title=user_data[2],
                    last_name=user_data[3],
                    department=user_data[4],
                    faculty=user_data[5]
                )
                conn.close()
                return user
        
        elif role == 'admin':
            cursor.execute('''
                SELECT username, email, first_name, last_name, faculty 
                FROM admins WHERE username = ?
            ''', (username,))
            user_data = cursor.fetchone()
            if user_data:
                user = User(
                    f"admin:{username}", 
                    username, 
                    'admin', 
                    user_data[1], 
                    f"{user_data[2]} {user_data[3]}",
                    faculty=user_data[4]
                )
                conn.close()
                return user
        
        conn.close()
        return None
    except Exception as e:
        print(f"Error loading user: {e}")
        return None

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def load_json_data():
    try:
        data_path = os.path.join(app.root_path, 'data', 'academic_programs.json')
        data_dir = os.path.dirname(data_path)

        if not os.path.exists(data_dir):
            os.makedirs(data_dir, exist_ok=True)

        if not os.path.exists(data_path):
            with open(data_path, 'w', encoding='utf-8') as f:
                json.dump({"programs": []}, f)
            return {"programs": []}

        with open(data_path, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                with open(data_path, 'w', encoding='utf-8') as fw:
                    json.dump({"programs": []}, fw)
                return {"programs": []}
    except (OSError, IOError) as e:
        print(f"Error loading JSON data: {e}")
        return {"programs": []}

def get_student_available_modules(program_code, year_level):
    json_data = load_json_data()
    for program in json_data.get('programs', []):
        if program['program_code'] == program_code:
            return [
                module for module in program['modules'] 
                if module['year_level'] == year_level
            ]
    return []

def get_module_details(module_code):
    json_data = load_json_data()
    for program in json_data.get('programs', []):
        for module in program['modules']:
            if module['module_code'] == module_code:
                return module
    return None

def send_email_notification(recipient, subject, body):
    try:
        msg = Message(
            subject=subject,
            recipients=[recipient],
            html=body
        )
        mail.send(msg)
        print(f"Email sent to {recipient}")
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def get_user_data_for_template(user):
    name_parts = user.name.split()
    if user.role == 'student':
        return {
            'first_name': name_parts[0] if name_parts else '',
            'surname': name_parts[1] if len(name_parts) > 1 else name_parts[0] if name_parts else '',
            'id': user.username
        }
    else:
        return {
            'first_name': name_parts[0] if name_parts else '',
            'surname': name_parts[1] if len(name_parts) > 1 else name_parts[0] if name_parts else '',
            'id': user.username
        }

def get_student_enrollments(student_id, academic_year=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if academic_year:
        cursor.execute('''
            SELECT * FROM student_modules 
            WHERE username = ? AND academic_year = ?
            ORDER BY academic_year DESC, semester, module_code
        ''', (student_id, academic_year))
    else:
        cursor.execute('''
            SELECT * FROM student_modules 
            WHERE username = ? 
            ORDER BY academic_year DESC, semester, module_code
        ''', (student_id,))
    
    enrollments = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return enrollments

def get_student_by_id(student_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT username, first_name, last_name, email, program_code, year_level 
        FROM students WHERE username = ?
    ''', (student_id,))
    student = cursor.fetchone()
    conn.close()
    return dict(student) if student else None

def get_student_requests(student_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM modification_requests 
        WHERE username = ? 
        ORDER BY created_at DESC
    ''', (student_id,))
    requests = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return requests

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user_type = request.form.get('userType', 'Student').strip()
        user_type_lower = user_type.lower()

        conn = get_db_connection()
        cursor = conn.cursor()
        user = None

        table_map = {
            'student': 'students',
            'lecturer': 'lecturers', 
            'hod': 'hods',
            'admin': 'admins'
        }

        table_name = table_map.get(user_type_lower)
        if table_name:
            cursor.execute(f'SELECT * FROM {table_name} WHERE username = ?', (username,))
            user_data = cursor.fetchone()

            if user_data:
                user_row = dict(user_data)
                if user_row.get('password') == password:
                    if user_type_lower == 'student':
                        user = User(
                            f"student:{username}", username, 'student', 
                            user_row.get('email'), f"{user_row.get('first_name','')} {user_row.get('last_name','')}",
                            program_code=user_row.get('program_code'),
                            year_level=user_row.get('year_level')
                        )
                    elif user_type_lower == 'lecturer':
                        name = f"{user_row.get('title','')} {user_row.get('last_name','')}".strip()
                        user = User(
                            f"lecturer:{username}", username, 'lecturer',
                            user_row.get('email'), name,
                            title=user_row.get('title'),
                            last_name=user_row.get('last_name'),
                            department=user_row.get('department'),
                            faculty=user_row.get('faculty')
                        )
                    elif user_type_lower == 'hod':
                        name = f"{user_row.get('title','')} {user_row.get('last_name','')}".strip()
                        user = User(
                            f"hod:{username}", username, 'hod',
                            user_row.get('email'), name,
                            title=user_row.get('title'),
                            last_name=user_row.get('last_name'),
                            department=user_row.get('department'),
                            faculty=user_row.get('faculty')
                        )
                    elif user_type_lower == 'admin':
                        user = User(
                            f"admin:{username}", username, 'admin',
                            user_row.get('email'), f"{user_row.get('first_name','')} {user_row.get('last_name','')}",
                            faculty=user_row.get('faculty')
                        )

        conn.close()

        if user:
            login_user(user)
            return jsonify({'success': True, 'message': f'Welcome back, {user.name}!', 'redirect_url': url_for('dashboard')})
        else:
            return jsonify({'success': False, 'message': 'Invalid username, password, or user type selection'})
    
    return render_template('login.html')

@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    try:
        logout_user()
        session.clear()
    except Exception as e:
        print(f"Logout error: {e}")

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.method == 'POST':
        return jsonify({'success': True, 'message': 'You have been logged out.', 'redirect': url_for('index')})

    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    role = current_user.role
    if role == 'student':
        return redirect(url_for('student_dashboard'))
    elif role == 'lecturer':
        return redirect(url_for('lecturer_dashboard'))
    elif role == 'hod':
        return redirect(url_for('hod_dashboard'))
    elif role == 'admin':
        return redirect(url_for('admin_dashboard'))
    else:
        flash('Unknown user role', 'error')
        return redirect(url_for('index'))

@app.route('/api/academic-record/<student_id>')
@login_required
def get_academic_record(student_id):
    try:
        if current_user.role == 'student' and current_user.username != student_id:
            return jsonify({'success': False, 'error': 'Access denied'}), 403
        
        enrollments = get_student_enrollments(student_id)
        
        total_credits = sum(enrollment.get('credits_earned', 0) for enrollment in enrollments)
        completed_modules = len([e for e in enrollments if e.get('status') == 'completed'])
        
        grade_points = {
            'A': 4.0, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 
            'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0.0
        }
        
        total_points = 0
        graded_modules = 0
        
        for enrollment in enrollments:
            if enrollment.get('grade') in grade_points:
                total_points += grade_points[enrollment['grade']]
                graded_modules += 1
        
        cumulative_gpa = round(total_points / graded_modules, 2) if graded_modules > 0 else 0.0
        
        yearly_performance = {}
        for enrollment in enrollments:
            year = enrollment.get('academic_year')
            if year not in yearly_performance:
                yearly_performance[year] = {
                    'modules': 0,
                    'credits': 0,
                    'gpa': 0.0
                }
            
            yearly_performance[year]['modules'] += 1
            yearly_performance[year]['credits'] += enrollment.get('credits_earned', 0)
            
            if enrollment.get('grade') in grade_points:
                yearly_performance[year]['gpa'] += grade_points[enrollment['grade']]
        
        for year, data in yearly_performance.items():
            graded_count = len([e for e in enrollments if e.get('academic_year') == year and e.get('grade') in grade_points])
            if graded_count > 0:
                data['gpa'] = round(data['gpa'] / graded_count, 2)
        
        academic_stats = {
            'total_credits': total_credits,
            'completed_modules': completed_modules,
            'cumulative_gpa': cumulative_gpa,
            'yearly_performance': yearly_performance
        }
        
        return jsonify({
            'success': True,
            'academic_stats': academic_stats,
            'enrollments': enrollments
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Academic Records API Endpoint
@app.route('/api/student/academic-history')
@login_required
def api_student_academic_history():
    if current_user.role != 'student':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    try:
        history = AR.get_student_academic_history(current_user.username)
        return jsonify({'success': True, 'records': history})
    except Exception as e:
        print('api_student_academic_history error:', e)
        return jsonify({'success': False, 'message': str(e)}), 500

# ========== ADMIN ACADEMIC RECORDS API ENDPOINTS ==========

@app.route('/api/admin/search-students')
@login_required
def admin_search_students():
    """Search students for academic records (ADMIN ONLY)"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        search_term = request.args.get('q', '').strip()
        program_filter = request.args.get('program', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = '''
            SELECT 
                username,
                first_name,
                last_name,
                email,
                program_code,
                year_level,
                enrollment_status,
                total_credits_earned
            FROM students 
            WHERE enrollment_status = 'active'
        '''
        params = []
        
        if search_term:
            query += ' AND (username LIKE ? OR first_name LIKE ? OR last_name LIKE ?)'
            search_pattern = f'%{search_term}%'
            params.extend([search_pattern, search_pattern, search_pattern])
        
        if program_filter:
            query += ' AND program_code = ?'
            params.append(program_filter)
        
        query += ' ORDER BY username LIMIT 50'
        
        cursor.execute(query, params)
        students = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            'success': True,
            'students': students
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/admin/student-enrollments/<username>')
@login_required
def admin_student_enrollments(username):
    """Get current enrollments for a student (ADMIN ONLY)"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get current year enrollments (assuming 2025 as current year)
        cursor.execute('''
            SELECT 
                sm.module_code,
                sm.module_name,
                pm.credits,
                pm.department,
                pm.year_level,
                sm.semester,
                sm.academic_year,
                sm.status
            FROM student_modules sm
            LEFT JOIN program_modules pm ON sm.module_code = pm.module_code
            WHERE sm.username = ? AND sm.academic_year = 2025
            ORDER BY sm.semester, sm.module_code
        ''', (username,))
        
        enrollments = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            'success': True,
            'enrollments': enrollments
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/admin/student-academic-history/<username>')
@login_required
def admin_student_academic_history(username):
    """Get complete academic history for a student (ADMIN ONLY)"""
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        # Use your existing AcademicRecordsSystem
        history = AR.get_student_academic_history(username)
        
        # Calculate statistics
        total_credits = sum(record.get('credits_earned', 0) for record in history)
        completed_modules = len([r for r in history if r.get('status') == 'completed'])
        failed_modules = len([r for r in history if r.get('grade') == 'F'])
        
        return jsonify({
            'success': True,
            'history': history,
            'total_credits': total_credits,
            'completed_modules': completed_modules,
            'failed_modules': failed_modules
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/student/dashboard')
@login_required
def student_dashboard():
    if current_user.role != 'student':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))

    student_data = get_user_data_for_template(current_user)

    conn = get_db_connection()
    cursor = conn.cursor()
    current_year = datetime.now().year
    
    cursor.execute('''
        SELECT module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned
        FROM student_modules 
        WHERE username = ? 
        ORDER BY academic_year DESC, semester, module_code
    ''', (current_user.username,))
    enrollments = cursor.fetchall()
    
    cursor.execute('''
        SELECT module_code, module_name, semester, academic_year, status, final_mark, grade, credits_earned
        FROM student_modules 
        WHERE username = ? AND academic_year = ?
        ORDER BY semester, module_code
    ''', (current_user.username, current_year))
    current_enrollments = cursor.fetchall()

    cursor.execute('''
        SELECT mr.*, 
               COALESCE(pm.module_name, mr.module_code) as subject_name,
               mr.module_code as subject_code
        FROM modification_requests mr
        LEFT JOIN program_modules pm ON mr.module_code = pm.module_code
        WHERE mr.username = ? 
        ORDER BY mr.created_at DESC
    ''', (current_user.username,))
    requests = cursor.fetchall()

    available_modules = get_student_available_modules(
        current_user.program_code,
        current_user.year_level
    )

    cursor.execute('''
        SELECT 
            COUNT(*) as total_modules,
            SUM(CASE WHEN status = 'completed' AND grade != 'F' THEN 1 ELSE 0 END) as passed_modules,
            SUM(CASE WHEN status = 'completed' AND grade = 'F' THEN 1 ELSE 0 END) as failed_modules,
            SUM(CASE WHEN status = 'registered' THEN 1 ELSE 0 END) as registered_modules,
            SUM(credits_earned) as total_credits_earned
        FROM student_modules 
        WHERE username = ?
    ''', (current_user.username,))
    
    stats = cursor.fetchone()
    
    cursor.execute('''
        SELECT academic_year, grade, credits_earned
        FROM student_modules 
        WHERE username = ? AND status = 'completed' AND grade IS NOT NULL
        ORDER BY academic_year
    ''', (current_user.username,))
    
    grade_data = cursor.fetchall()
    
    grade_points = {'A': 4.0, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0.0}
    
    total_points = 0
    graded_modules = 0
    yearly_performance = {}
    
    for row in grade_data:
        grade = row['grade']
        year = row['academic_year']
        credits = row['credits_earned'] or 0
        
        if year not in yearly_performance:
            yearly_performance[year] = {
                'modules': 0,
                'credits': 0,
                'gpa': 0.0
            }
        
        yearly_performance[year]['modules'] += 1
        yearly_performance[year]['credits'] += credits
        
        if grade in grade_points:
            total_points += grade_points[grade]
            graded_modules += 1
            yearly_performance[year]['gpa'] += grade_points[grade]
    
    for year, data in yearly_performance.items():
        graded_count = len([r for r in grade_data if r['academic_year'] == year and r['grade'] in grade_points])
        if graded_count > 0:
            data['gpa'] = round(data['gpa'] / graded_count, 2)
    
    cumulative_gpa = round(total_points / graded_modules, 2) if graded_modules > 0 else 0.0

    # --- add: load academic history for template ---
    try:
        academic_history = AR.get_student_academic_history(current_user.username)
    except Exception:
        academic_history = []
    # --- end add ---

    conn.close()

    all_enrollments_list = [dict(row) for row in enrollments]
    
    academic_stats = {
        'total_modules': stats['total_modules'] if stats else 0,
        'passed_modules': stats['passed_modules'] if stats else 0,
        'failed_modules': stats['failed_modules'] if stats else 0,
        'registered_modules': stats['registered_modules'] if stats else 0,
        'total_credits': stats['total_credits_earned'] if stats else 0,
        'cumulative_gpa': cumulative_gpa,
        'yearly_performance': yearly_performance
    }

    return render_template('student_dashboard.html',
                         student=student_data,
                         enrollments=current_enrollments,
                         all_enrollments=all_enrollments_list,
                         requests=requests,
                         available_modules=available_modules,
                         current_year=current_year,
                         academic_stats=academic_stats,
                         academic_history=academic_history)

@app.route('/student/submit-request', methods=['POST'])
@login_required
def submit_request():
    if current_user.role != 'student':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        print(f"Received request data: {data}")
        
        if not data:
            return jsonify({'success': False, 'error': 'No JSON data received'})
        
        request_type = data.get('request_type')
        reason = data.get('reason', '')
        modules = data.get('modules', [])
        
        print(f"Request type: {request_type}, Reason: {reason}, Modules: {modules}")
        
        if not modules:
            return jsonify({'success': False, 'error': 'No modules provided'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        request_ids = []
        successful_modules = []
        failed_modules = []
        
        for module in modules:
            module_code = module.get('module_code')
            module_name = module.get('module_name')
            semester = module.get('semester')
            
            print(f"Processing module: {module_code} - {module_name} (Semester: {semester})")
            
            if not module_code:
                failed_modules.append("Missing module code")
                continue
            
            # Check if module exists in program_modules
            cursor.execute('SELECT module_name, semester FROM program_modules WHERE module_code = ?', (module_code,))
            module_exists = cursor.fetchone()
            
            if not module_exists:
                print(f"Module {module_code} not found in program_modules")
                failed_modules.append(f"{module_code}: Module not found in system")
                continue
            
            # === ADD SEMESTER VALIDATION HERE ===
            module_semester = module_exists['semester']
            if request_type == 'add' and str(module_semester) != str(current_semester):
                failed_modules.append(f"{module_code}: You can only add modules from the current semester (Semester {current_semester})")
                continue
            # === END SEMESTER VALIDATION ===
            
            # Check for duplicate pending requests
            cursor.execute('''
                SELECT 1 FROM modification_requests 
                WHERE username = ? AND module_code = ? AND status LIKE 'pending%'
            ''', (current_user.username, module_code))
            
            if cursor.fetchone():
                failed_modules.append(f"{module_code}: You already have a pending request for this module")
                continue
            
            try:
                cursor.execute('''
                    INSERT INTO modification_requests 
                    (username, module_code, request_type, reason, semester, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, 'pending_lecturer', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                ''', (current_user.username, module_code, request_type, reason, semester))
                
                request_id = cursor.lastrowid
                request_ids.append(request_id)
                successful_modules.append(f"{module_code} - {module_exists['module_name']}")
                print(f"Successfully inserted request for module {module_code}, request_id: {request_id}")
                
            except sqlite3.Error as e:
                print(f"Database error inserting request for module {module_code}: {str(e)}")
                failed_modules.append(f"{module_code}: Database error - {str(e)}")
            except Exception as e:
                print(f"Error inserting request for module {module_code}: {str(e)}")
                failed_modules.append(f"{module_code}: {str(e)}")
        
        conn.commit()
        conn.close()
        
        print(f"Request submission completed. Successful: {successful_modules}, Failed: {failed_modules}")
        
        # Send email notifications only if successful
        if successful_modules:
            try:
                lecturer_email = "lecturer.cs1@unizulu.ac.za"
                email_subject = f"New Module Modification Request - {len(successful_modules)} module(s)"
                email_body = f"""
                <h3>New Module Modification Request</h3>
                <p><strong>Student:</strong> {current_user.name} ({current_user.username})</p>
                <p><strong>Number of Modules:</strong> {len(successful_modules)}</p>
                <p><strong>Request Type:</strong> {request_type}</p>
                <p><strong>Reason:</strong> {reason}</p>
                <p>Please review these requests in your lecturer dashboard.</p>
                """
                
                send_email_notification(lecturer_email, email_subject, email_body)
            except Exception as email_error:
                print(f"Email notification failed: {email_error}")
                # Don't fail the whole request if email fails
        
        response_data = {
            'success': True if successful_modules else False, 
            'message': f'Modification requests submitted successfully for {len(successful_modules)} module(s)!' if successful_modules else 'No modules were successfully submitted.',
            'request_ids': request_ids,
            'successful_modules': successful_modules,
            'failed_modules': failed_modules
        }
        
        if failed_modules:
            response_data['warning'] = f'Failed to submit {len(failed_modules)} module(s)'
        
        return jsonify(response_data)
        
    except Exception as e:
        print(f"Error in submit_request: {str(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        return jsonify({'success': False, 'error': f'Server error: {str(e)}'})

# ========== LECTURER ROUTES ==========

@app.route('/lecturer/dashboard')
@login_required
def lecturer_dashboard():
    if current_user.role != 'lecturer':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    user_data = {
        'name': current_user.name,
        'first_name': getattr(current_user, 'title', ''),
        'surname': getattr(current_user, 'last_name', ''),
        'department': getattr(current_user, 'department', 'University of Zululand'),
        'email': current_user.email
    }
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT ma.module_code, pm.module_name 
            FROM module_assignments ma
            JOIN program_modules pm ON ma.module_code = pm.module_code
            WHERE ma.lecturer_username = ?
        ''', (current_user.username,))
        lecturer_modules = cursor.fetchall()
        
        pending_requests = []
        if lecturer_modules:
            module_codes = [row['module_code'] for row in lecturer_modules]
            placeholders = ','.join(['?' for _ in module_codes])
            
            cursor.execute(f'''
                SELECT 
                    mr.request_id,
                    mr.username as student_username,
                    mr.module_code,
                    mr.request_type,
                    mr.reason,
                    mr.status as request_status,
                    mr.created_at as request_date,
                    s.first_name as student_first_name,
                    s.last_name as student_last_name,
                    s.program_code,
                    s.year_level,
                    s.email as student_email,
                    pm.module_name
                FROM modification_requests mr
                JOIN students s ON mr.username = s.username
                JOIN program_modules pm ON mr.module_code = pm.module_code
                WHERE mr.module_code IN ({placeholders}) 
                AND mr.status = 'pending_lecturer'
                ORDER BY mr.created_at DESC
            ''', module_codes)
            
            requests = cursor.fetchall()
            
            for request in requests:
                req_dict = dict(request)
                req_dict.update({
                    'subject_code': request['module_code'],
                    'subject_name': request['module_name'],
                    'student_number': request['student_username'],
                    'first_name': request['student_first_name'],
                    'surname': request['student_last_name'],
                    'qualification': request['program_code'],
                    'student_email': request['student_email'],
                    'lecturer_name': current_user.name
                })
                pending_requests.append(req_dict)
        
        cursor.execute('''
            SELECT COUNT(*) as assigned_modules 
            FROM module_assignments 
            WHERE lecturer_username = ?
        ''', (current_user.username,))
        assigned_modules = cursor.fetchone()['assigned_modules']
        
        cursor.execute('''
            SELECT COUNT(*) as pending_requests_count
            FROM modification_requests mr
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE ma.lecturer_username = ? AND mr.status = 'pending_lecturer'
        ''', (current_user.username,))
        pending_count = cursor.fetchone()['pending_requests_count']
        
        conn.close()
        
        return render_template('lecturer_dashboard.html',
                             user=user_data,
                             requests=pending_requests,
                             assigned_modules=assigned_modules,
                             pending_count=pending_count)
                             
    except Exception as e:
        print(f"Error in lecturer_dashboard: {e}")
        flash(f'Error loading dashboard: {str(e)}', 'error')
        return render_template('lecturer_dashboard.html',
                             user=user_data,
                             requests=[],
                             assigned_modules=0,
                             pending_count=0)

@app.route('/lecturer/approve-request/<int:request_id>', methods=['POST'])
@login_required
def approve_lecturer_request(request_id):
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        comment = data.get('comment', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE mr.request_id = ? AND ma.lecturer_username = ?
        ''', (request_id, current_user.username))
        
        request_data = cursor.fetchone()
        if not request_data:
            return jsonify({'success': False, 'error': 'Not authorized to approve this request'})
        
        cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
        student_email_result = cursor.fetchone()
        student_email = student_email_result['email'] if student_email_result else None
        
        cursor.execute('''
            UPDATE modification_requests 
            SET status = 'pending_hod',
                lecturer_username = ?,
                lecturer_comment = ?,
                lecturer_signed_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE request_id = ?
        ''', (current_user.username, comment, request_id))
        
        conn.commit()
        
        hod_email = "hod.cs@unizulu.ac.za"
        email_subject = f"Module Request Approved by Lecturer - Request #{request_id}"
        email_body = f"""
        <h3>Module Request Approved by Lecturer</h3>
        <p><strong>Request ID:</strong> #{request_id}</p>
        <p><strong>Student:</strong> {request_data['first_name']} {request_data['last_name']} ({request_data['username']})</p>
        <p><strong>Module:</strong> {request_data['module_code']}</p>
        <p><strong>Request Type:</strong> {request_data['request_type']}</p>
        <p><strong>Lecturer Comments:</strong> {comment}</p>
        <p>Please review this request in your HOD dashboard.</p>
        """
        
        send_email_notification(hod_email, email_subject, email_body)
        
        if student_email:
            student_subject = f"Module Request Update - Request #{request_id}"
            student_body = f"""
            <h3>Module Request Update</h3>
            <p>Your module modification request has been approved by the lecturer.</p>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Module:</strong> {request_data['module_code']}</p>
            <p><strong>Status:</strong> Approved by Lecturer - Forwarded to HOD</p>
            <p><strong>Lecturer Comments:</strong> {comment}</p>
            """
            
            send_email_notification(student_email, student_subject, student_body)
        
        conn.close()
        
        return jsonify({'success': True, 'message': 'Request approved and forwarded to HOD successfully!'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/lecturer/reject-request/<int:request_id>', methods=['POST'])
@login_required
def reject_lecturer_request(request_id):
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        comment = data.get('comment', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE mr.request_id = ? AND ma.lecturer_username = ?
        ''', (request_id, current_user.username))
        
        request_data = cursor.fetchone()
        if not request_data:
            return jsonify({'success': False, 'error': 'Not authorized to reject this request'})
        
        cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
        student_email_result = cursor.fetchone()
        student_email = student_email_result['email'] if student_email_result else None
        
        cursor.execute('''
            UPDATE modification_requests 
            SET status = 'rejected_lecturer',
                lecturer_username = ?,
                lecturer_comment = ?,
                lecturer_signed_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE request_id = ?
        ''', (current_user.username, comment, request_id))
        
        conn.commit()
        
        if student_email:
            student_subject = f"Module Request Decision - Request #{request_id}"
            student_body = f"""
            <h3>Module Request Decision</h3>
            <p>Your module modification request has been reviewed by the lecturer.</p>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Module:</strong> {request_data['module_code']}</p>
            <p><strong>Status:</strong> Rejected by Lecturer</p>
            <p><strong>Lecturer Comments:</strong> {comment}</p>
            <p>Please contact your lecturer if you have any questions.</p>
            """
            
            send_email_notification(student_email, student_subject, student_body)
        
        conn.close()
        
        return jsonify({'success': True, 'message': 'Request rejected.'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ========== LECTURER API ROUTES ==========

@app.route('/api/lecturer/profile')
@login_required
def api_lecturer_profile():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT username, title, last_name, department, email, faculty
            FROM lecturers WHERE username = ?
        ''', (current_user.username,))
        
        lecturer = cursor.fetchone()
        conn.close()
        
        if lecturer:
            lecturer_dict = dict(lecturer)
            lecturer_dict['name'] = f"{lecturer_dict.get('title', '')} {lecturer_dict.get('last_name', '')}".strip()
            lecturer_dict['first_name'] = lecturer_dict.get('title', '')
            lecturer_dict['surname'] = lecturer_dict.get('last_name', '')
            
            return jsonify({
                'success': True,
                'lecturer': lecturer_dict
            })
        else:
            return jsonify({'success': False, 'message': 'Lecturer not found'})
            
    except Exception as e:
        print(f"Error in api_lecturer_profile: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/dashboard-overview')
@login_required
def api_lecturer_dashboard_overview():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*) as count FROM module_assignments 
            WHERE lecturer_username = ?
        ''', (current_user.username,))
        assigned_modules = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT COUNT(*) as count 
            FROM modification_requests mr
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE ma.lecturer_username = ? AND mr.status = 'pending_lecturer'
        ''', (current_user.username,))
        pending_requests = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT COUNT(*) as count 
            FROM modification_requests 
            WHERE lecturer_signed_at IS NOT NULL
        ''')
        approved_requests = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT 
                mr.request_id,
                mr.username as student_username,
                mr.module_code,
                mr.request_type,
                mr.reason,
                mr.status as request_status,
                mr.created_at as request_date,
                s.first_name as student_first_name,
                s.last_name as student_last_name,
                s.program_code,
                s.year_level,
                pm.module_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN program_modules pm ON mr.module_code = pm.module_code
            WHERE mr.module_code IN (
                SELECT module_code FROM module_assignments 
                WHERE lecturer_username = ?
            )
            ORDER BY mr.created_at DESC
            LIMIT 5
        ''', (current_user.username,))
        
        recent_requests = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'data': {
                'assigned_modules': assigned_modules,
                'pending_requests': pending_requests,
                'approved_requests': approved_requests,
                'total_students': 0,
                'recent_requests': recent_requests
            }
        })
        
    except Exception as e:
        print(f"Error in api_lecturer_dashboard_overview: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/module-requests')
@login_required
def api_lecturer_module_requests():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    status_filter = request.args.get('status', 'all')
    module_filter = request.args.get('module', 'all')
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = '''
            SELECT 
                mr.request_id,
                mr.username as student_username,
                mr.module_code,
                mr.request_type,
                mr.reason,
                mr.status as request_status,
                mr.created_at as request_date,
                s.first_name as student_first_name,
                s.last_name as student_last_name,
                s.program_code,
                s.year_level,
                pm.module_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN program_modules pm ON mr.module_code = pm.module_code
            WHERE mr.module_code IN (
                SELECT module_code FROM module_assignments 
                WHERE lecturer_username = ?
            )
        '''
        
        params = [current_user.username]
        
        if status_filter != 'all':
            query += ' AND mr.status = ?'
            params.append(status_filter)
        else:
            query += ' AND mr.status LIKE "pending%"'
        
        if module_filter != 'all':
            query += ' AND mr.module_code = ?'
            params.append(module_filter)
        
        query += ' ORDER BY mr.created_at DESC'
        
        cursor.execute(query, params)
        requests = [dict(row) for row in cursor.fetchall()]
        
        cursor.execute('''
            SELECT ma.module_code, pm.module_name
            FROM module_assignments ma
            JOIN program_modules pm ON ma.module_code = pm.module_code
            WHERE ma.lecturer_username = ?
        ''', (current_user.username,))
        modules = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'requests': requests,
            'modules': modules
        })
        
    except Exception as e:
        print(f"Error in api_lecturer_module-requests: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/my-modules')
@login_required
def api_lecturer_my_modules():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                ma.module_code,
                pm.module_name,
                (SELECT COUNT(*) FROM student_modules WHERE module_code = ma.module_code) as student_count,
                (SELECT COUNT(*) FROM modification_requests WHERE module_code = ma.module_code AND status = 'pending_lecturer') as pending_requests
            FROM module_assignments ma
            JOIN program_modules pm ON ma.module_code = pm.module_code
            WHERE ma.lecturer_username = ?
        ''', (current_user.username,))
        
        modules = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            'success': True,
            'modules': modules
        })
        
    except Exception as e:
        print(f"Error in api_lecturer_my_modules: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/review-history')
@login_required
def api_lecturer_review_history():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name as student_first_name, s.last_name as student_last_name, 
                   s.username as student_username
            FROM modification_requests mr
            JOIN students s on mr.username = s.username
            WHERE mr.lecturer_username = ? AND mr.lecturer_signed_at IS NOT NULL
            ORDER BY mr.lecturer_signed_at DESC
        ''', (current_user.username,))
        
        history = []
        for row in cursor.fetchall():
            history_dict = dict(row)
            module_details = get_module_details(history_dict['module_code'])
            if module_details:
                history_dict['module_name'] = module_details['module_name']
            history.append(history_dict)
        
        conn.close()
        
        return jsonify({
            'success': True,
            'history': history
        })
        
    except Exception as e:
        print(f"Error in api_lecturer_review_history: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/request-details/<int:request_id>')
@login_required
def api_lecturer_request_details(request_id):
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                mr.*,
                s.first_name as student_first_name,
                s.last_name as student_last_name,
                s.program_code,
                s.year_level,
                pm.module_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN program_modules pm ON mr.module_code = pm.module_code
            WHERE mr.request_id = ? AND mr.module_code IN (
                SELECT module_code FROM module_assignments 
                WHERE lecturer_username = ?
            )
        ''', (request_id, current_user.username))
        
        request_data = cursor.fetchone()
        conn.close()
        
        if request_data:
            return jsonify({
                'success': True,
                'request': dict(request_data)
            })
        else:
            return jsonify({'success': False, 'message': 'Request not found or access denied'})
            
    except Exception as e:
        print(f"Error in api_lecturer_request_details: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/pending-count')
@login_required
def api_lecturer_pending_count():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*) as count 
            FROM modification_requests mr
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE ma.lecturer_username = ? AND mr.status = 'pending_lecturer'
        ''', (current_user.username,))
        
        count = cursor.fetchone()['count']
        conn.close()
        
        return jsonify({
            'success': True,
            'count': count
        })
        
    except Exception as e:
        print(f"Error in api_lecturer_pending-count: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lecturer/sign-request', methods=['POST'])
@login_required
def api_lecturer_sign_request():
    if current_user.role != 'lecturer':
        return jsonify({'success': False, 'message': 'Access denied'}), 403
    
    try:
        data = request.get_json()
        request_id = data.get('request_id')
        signature = data.get('signature', '')
        comment = data.get('comment', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            JOIN module_assignments ma ON mr.module_code = ma.module_code
            WHERE mr.request_id = ? AND ma.lecturer_username = ?
        ''', (request_id, current_user.username))
        
        request_data = cursor.fetchone()
        if not request_data:
            conn.close()
            return jsonify({'success': False, 'message': 'Not authorized to sign this request'})
        
        cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
        student_email_result = cursor.fetchone()
        student_email = student_email_result['email'] if student_email_result else None
        
        cursor.execute('''
            UPDATE modification_requests 
            SET status = 'pending_hod',
                lecturer_username = ?,
                lecturer_comment = ?,
                lecturer_signed_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE request_id = ?
        ''', (current_user.username, comment, request_id))
        
        conn.commit()
        
        hod_email = "hod.cs@unizulu.ac.za"
        request_dict = dict(request_data)
        email_subject = f"Module Request Signed by Lecturer - Request #{request_id}"
        email_body = f"""
        <h3>Module Request Signed by Lecturer</h3>
        <p><strong>Request ID:</strong> #{request_id}</p>
        <p><strong>Student:</strong> {request_dict['first_name']} {request_dict['last_name']} ({request_dict['username']})</p>
        <p><strong>Module:</strong> {request_dict['module_code']}</p>
        <p><strong>Request Type:</strong> {request_dict['request_type']}</p>
        <p><strong>Lecturer Comments:</strong> {comment}</p>
        <p>Please review this request in your HOD dashboard.</p>
        """
        
        send_email_notification(hod_email, email_subject, email_body)
        
        if student_email:
            student_subject = f"Module Request Update - Request #{request_id}"
            student_body = f"""
            <h3>Module Request Update</h3>
            <p>Your module modification request has been signed by the lecturer and forwarded to the HOD.</p>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Module:</strong> {request_dict['module_code']}</p>
            <p><strong>Status:</strong> Forwarded to HOD for Review</p>
            <p><strong>Lecturer Comments:</strong> {comment}</p>
            """
            
            send_email_notification(student_email, student_subject, student_body)
        
        conn.close()
        
        return jsonify({'success': True, 'message': 'Request signed successfully!'})
        
    except Exception as e:
        print(f"Error signing lecturer request: {e}")
        return jsonify({'success': False, 'message': str(e)})

# ========== HOD ROUTES ==========

@app.route('/hod/dashboard')
@login_required
def hod_dashboard():
    if current_user.role != 'hod':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    user_data = get_user_data_for_template(current_user)
    
    # Get requests for HOD's department
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT mr.*, s.first_name, s.last_name, s.program_code, s.email as student_email,
               l.title as lecturer_title, l.last_name as lecturer_last_name,
               pm.department as module_department, pm.module_name
        FROM modification_requests mr
        JOIN students s ON mr.username = s.username
        LEFT JOIN lecturers l ON mr.lecturer_username = l.username
        LEFT JOIN program_modules pm ON mr.module_code = pm.module_code
        WHERE mr.status = 'pending_hod'
        ORDER BY mr.lecturer_signed_at DESC
    ''')
    
    department_requests = []
    requests = cursor.fetchall()
    for request in requests:
        request_dict = dict(request)
        module_department = request_dict.get('module_department')
        hod_department = getattr(current_user, 'department', '')
        
        # Show all requests to HOD (removed department filter to fix "No Pending Requests")
        request_dict.update({
            'subject_code': request['module_code'],
            'subject_name': request_dict.get('module_name', 'Unknown Module'),
            'student_number': request['username'],
            'first_name': request['first_name'],
            'surname': request['last_name'],
            'qualification': request['program_code'],
            'student_email': request['student_email'],
            'lecturer_name': f"{request['lecturer_title']} {request['lecturer_last_name']}" if request['lecturer_title'] else 'N/A'
        })
        department_requests.append(request_dict)
    
    conn.close()
    
    return render_template('hod_dashboard.html',
                         user=user_data,
                         requests=department_requests,
                         department=current_user.department)

@app.route('/hod/department-modules')
@login_required
def hod_department_modules():
    """Get all modules for HOD's department"""
    if current_user.role != 'hod':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get modules for HOD's department
        cursor.execute('''
            SELECT 
                pm.module_code,
                pm.module_name,
                pm.credits,
                pm.nqf_level,
                pm.semester,
                pm.year_level,
                pm.prerequisites,
                pm.corequisites,
                pm.program_codes,
                COUNT(DISTINCT ma.lecturer_username) as assigned_lecturers,
                COUNT(DISTINCT sm.username) as enrolled_students
            FROM program_modules pm
            LEFT JOIN module_assignments ma ON pm.module_code = ma.module_code
            LEFT JOIN student_modules sm ON pm.module_code = sm.module_code 
                AND sm.academic_year = 2025 
                AND sm.semester = '2'
            WHERE pm.department = ?
            GROUP BY pm.module_code, pm.module_name, pm.credits, pm.nqf_level, pm.semester, pm.year_level
            ORDER BY pm.year_level, pm.semester, pm.module_code
        ''', (current_user.department,))
        
        modules = [dict(row) for row in cursor.fetchall()] or []
        
        # Get department statistics
        cursor.execute('''
            SELECT 
                COUNT(DISTINCT pm.module_code) as total_modules,
                COUNT(DISTINCT ma.lecturer_username) as total_lecturers,
                COUNT(DISTINCT sm.username) as total_students,
                SUM(pm.credits) as total_credits
            FROM program_modules pm
            LEFT JOIN module_assignments ma ON pm.module_code = ma.module_code
            LEFT JOIN student_modules sm ON pm.module_code = sm.module_code 
                AND sm.academic_year = 2025 
                AND sm.semester = '2'
            WHERE pm.department = ?
        ''', (current_user.department,))
        
        stats_result = cursor.fetchone()
        stats = dict(stats_result) if stats_result else {}
        
        conn.close()
        
        return jsonify({
            'success': True,
            'modules': modules,
            'stats': stats,
            'department': current_user.department
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/hod/get_request_details/<int:request_id>')
@login_required
def get_hod_request_details(request_id):
    if current_user.role != 'hod':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                mr.*,
                s.first_name as student_first_name,
                s.last_name as student_last_name,
                s.program_code,
                s.year_level,
                pm.module_name,
                l.title as lecturer_title,
                l.last_name as lecturer_last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            LEFT JOIN program_modules pm ON mr.module_code = pm.module_code
            LEFT JOIN lecturers l ON mr.lecturer_username = l.username
            WHERE mr.request_id = ? AND mr.status = 'pending_hod'
        ''', (request_id,))
        
        request_data = cursor.fetchone()
        conn.close()
        
        if request_data:
            return jsonify(dict(request_data))
        else:
            return jsonify({'error': 'Request not found or not available for HOD review'}), 404
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/hod/recommend-request/<int:request_id>', methods=['POST'])
@login_required
def recommend_hod_request(request_id):
    if current_user.role != 'hod':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        comment = data.get('comment', '')
        recommendation = data.get('recommendation', 'approve')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            WHERE mr.request_id = ? AND mr.status = 'pending_hod'
        ''', (request_id,))
        
        request_data = cursor.fetchone()
        
        if request_data:
            cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
            student_email_result = cursor.fetchone()
            student_email = student_email_result['email'] if student_email_result else None
            
            # Removed department check to allow HOD to process all pending requests
            new_status = 'recommended_hod' if recommendation == 'approve' else 'rejected_hod'
            
            cursor.execute('''
                UPDATE modification_requests 
                SET status = ?,
                    hod_username = ?,
                    hod_comment = ?,
                    hod_recommended_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP
                WHERE request_id = ?
            ''', (new_status, current_user.username, comment, request_id))
            
            conn.commit()
            
            admin_email = "admin1@unizulu.ac.za"
            action = "recommended" if recommendation == 'approve' else "rejected"
            email_subject = f"Module Request {action.capitalize()} by HOD - Request #{request_id}"
            email_body = f"""
            <h3>Module Request {action.capitalize()} by HOD</h3>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Student:</strong> {request_data['first_name']} {request_data['last_name']} ({request_data['username']})</p>
            <p><strong>Module:</strong> {request_data['module_code']}</p>
            <p><strong>Request Type:</strong> {request_data['request_type']}</p>
            <p><strong>HOD Comments:</strong> {comment}</p>
            <p>Please review this request in your admin dashboard.</p>
            """
            
            send_email_notification(admin_email, email_subject, email_body)
            
            if student_email:
                student_subject = f"Module Request Update - Request #{request_id}"
                student_body = f"""
                <h3>Module Request Update</h3>
                <p>Your module modification request has been {action} by the HOD.</p>
                <p><strong>Request ID:</strong> #{request_id}</p>
                <p><strong>Module:</strong> {request_data['module_code']}</p>
                <p><strong>Status:</strong> {action.capitalize()} by HOD</p>
                <p><strong>HOD Comments:</strong> {comment}</p>
                """
                
                send_email_notification(student_email, student_subject, student_body)
            
            conn.close()
            
            return jsonify({'success': True, 'message': f'Request {action} successfully!'})
        else:
            return jsonify({'success': False, 'error': 'Request not found'})
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ========== ADMIN ROUTES ==========

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash('Access denied.', 'error')
        return redirect(url_for('dashboard'))
    
    user_data = get_user_data_for_template(current_user)
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            SELECT 
                mr.*, 
                s.first_name, 
                s.last_name, 
                s.program_code, 
                s.email as student_email,
                l.title as lecturer_title, 
                l.last_name as lecturer_last_name,
                l.email as lecturer_email,
                h.title as hod_title, 
                h.last_name as hod_last_name,
                h.email as hod_email,
                pm.module_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            LEFT JOIN lecturers l ON mr.lecturer_username = l.username
            LEFT JOIN hods h ON mr.hod_username = h.username
            LEFT JOIN program_modules pm ON mr.module_code = pm.module_code
            WHERE mr.status = 'recommended_hod'
            ORDER BY mr.hod_recommended_at DESC
        ''')
        
        admin_requests = []
        requests = cursor.fetchall()
        
        for request in requests:
            request_dict = dict(request)
            
            # Get lecturer information
            lecturer_name = "No lecturer approval"
            if request_dict['lecturer_title'] and request_dict['lecturer_last_name']:
                lecturer_name = f"{request_dict['lecturer_title']} {request_dict['lecturer_last_name']}"
            
            # Get HOD information
            hod_name = "No HOD recommendation"
            hod_comments = "No HOD comments"
            if request_dict['hod_title'] and request_dict['hod_last_name']:
                hod_name = f"{request_dict['hod_title']} {request_dict['hod_last_name']}"
                hod_comments = request_dict.get('hod_comment', 'No HOD comments')
            
            # Get lecturer comments
            lecturer_comments = request_dict.get('lecturer_comment', 'No lecturer comments')
            
            request_dict.update({
                'subject_code': request_dict['module_code'],
                'subject_name': request_dict.get('module_name', 'Unknown Module'),
                'student_number': request_dict['username'],
                'first_name': request_dict['first_name'],
                'surname': request_dict['last_name'],
                'qualification': request_dict['program_code'],
                'student_email': request_dict['student_email'],
                'lecturer_name': lecturer_name,
                'lecturer_comments': lecturer_comments,
                'hod_name': hod_name,
                'hod_comments': hod_comments
            })
            admin_requests.append(request_dict)
        
        # Get statistics
        cursor.execute('''
            SELECT 
                COUNT(*) as total_students,
                SUM(CASE WHEN year_level = 1 THEN 1 ELSE 0 END) as first_year,
                SUM(CASE WHEN year_level = 2 THEN 1 ELSE 0 END) as second_year,
                SUM(CASE WHEN year_level = 3 THEN 1 ELSE 0 END) as third_year
            FROM students 
            WHERE enrollment_status = 'active'
        ''')
        
        stats_result = cursor.fetchone()
        stats = dict(stats_result) if stats_result else {
            'total_students': 0,
            'first_year': 0,
            'second_year': 0,
            'third_year': 0
        }
        
        conn.close()
        
        return render_template('admin_dashboard.html',
                             user=user_data,
                             requests=admin_requests,
                             stats=stats)
                             
    except Exception as e:
        print(f"Error in admin_dashboard: {e}")
        flash('Error loading dashboard data', 'error')
        return render_template('admin_dashboard.html',
                             user=user_data,
                             requests=[],
                             stats={})

@app.route('/admin/approve-request/<int:request_id>', methods=['POST'])
@login_required
def approve_admin_request(request_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        comment = data.get('comment', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            WHERE mr.request_id = ?
        ''', (request_id,))
        
        request_data = cursor.fetchone()
        
        if not request_data:
            return jsonify({'success': False, 'error': 'Request not found'})
        
        cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
        student_email_result = cursor.fetchone()
        student_email = student_email_result['email'] if student_email_result else None
        
        cursor.execute('''
            UPDATE modification_requests 
            SET status = 'approved_admin',
                admin_username = ?,
                admin_comment = ?,
                admin_approved_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE request_id = ?
        ''', (current_user.username, comment, request_id))
        
        if request_data['request_type'] == 'add':
            module_details = get_module_details(request_data['module_code'])
            if module_details:
                cursor.execute('''
                    INSERT OR REPLACE INTO student_modules 
                    (username, module_code, module_name, semester, academic_year, status, added_at)
                    VALUES (?, ?, ?, ?, ?, 'registered', datetime('now'))
                ''', (
                    request_data['username'],
                    request_data['module_code'],
                    module_details['module_name'],
                    module_details['semester'],
                    datetime.now().year,
                    'registered'
                ))
        
        elif request_data['request_type'] == 'cancel':
            cursor.execute('''
                DELETE FROM student_modules 
                WHERE username = ? AND module_code = ?
            ''', (request_data['username'], request_data['module_code']))
        
        conn.commit()
        
        if student_email:
            student_subject = f"Module Request Final Decision - Request #{request_id}"
            student_body = f"""
            <h3>Module Request Final Decision</h3>
            <p>Your module modification request has been <strong>APPROVED</strong> by the administration.</p>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Module:</strong> {request_data['module_code']}</p>
            <p><strong>Request Type:</strong> {request_data['request_type']}</p>
            <p><strong>Status:</strong> APPROVED - Completed</p>
            <p><strong>Administrative Comments:</strong> {comment}</p>
            <p>Your student record has been updated accordingly.</p>
            """
            
            send_email_notification(student_email, student_subject, student_body)
        
        conn.close()
        
        return jsonify({'success': True, 'message': 'Request approved and processed successfully!'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/reject-request/<int:request_id>', methods=['POST'])
@login_required
def reject_admin_request(request_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'})
    
    try:
        data = request.get_json()
        comment = data.get('comment', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT mr.*, s.first_name, s.last_name
            FROM modification_requests mr
            JOIN students s ON mr.username = s.username
            WHERE mr.request_id = ?
        ''', (request_id,))
        
        request_data = cursor.fetchone()
        
        if not request_data:
            return jsonify({'success': False, 'error': 'Request not found'})
        
        cursor.execute('SELECT email FROM students WHERE username = ?', (request_data['username'],))
        student_email_result = cursor.fetchone()
        student_email = student_email_result['email'] if student_email_result else None
        
        cursor.execute('''
            UPDATE modification_requests 
            SET status = 'rejected_admin',
                admin_username = ?,
                admin_comment = ?,
                admin_approved_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE request_id = ?
        ''', (current_user.username, comment, request_id))
        
        conn.commit()
        
        if student_email:
            student_subject = f"Module Request Final Decision - Request #{request_id}"
            student_body = f"""
            <h3>Module Request Final Decision</h3>
            <p>Your module modification request has been <strong>REJECTED</strong> by the administration.</p>
            <p><strong>Request ID:</strong> #{request_id}</p>
            <p><strong>Module:</strong> {request_data['module_code']}</p>
            <p><strong>Request Type:</strong> {request_data['request_type']}</p>
            <p><strong>Status:</strong> REJECTED</p>
            <p><strong>Administrative Comments:</strong> {comment}</p>
            <p>Please contact the administration office if you have any questions.</p>
            """
            
            send_email_notification(student_email, student_subject, student_body)
        
        conn.close()
        
        return jsonify({'success': True, 'message': 'Request rejected.'})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# ========== API ROUTES ==========

@app.route('/api/student/modules')
@login_required
def get_student_modules():
    if current_user.role != 'student':
        return jsonify({'error': 'Access denied'})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT module_code, module_name, semester, academic_year, status 
        FROM student_modules 
        WHERE username = ? AND academic_year = 2024
        ORDER BY semester, module_code
    ''', (current_user.username,))
    
    modules = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({'modules': modules})

@app.route('/api/student/requests')
@login_required
def get_student_requests():
    if current_user.role != 'student':
        return jsonify({'error': 'Access denied'})
    
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM modification_requests 
        WHERE username = ? 
        ORDER BY created_at DESC
    ''', (current_user.username,))
    
    requests = [dict(row) for row in cursor.fetchall()]
    conn.close()
    
    return jsonify({'requests': requests})

@app.route('/api/admin/academic-overview')
@login_required
def admin_academic_overview():
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                s.username,
                s.first_name,
                s.last_name,
                s.program_code,
                p.program_name,
                s.year_level,
                s.total_credits_earned,
                COUNT(sm.id) as total_modules,
                SUM(CASE WHEN sm.status = 'completed' AND sm.grade != 'F' THEN 1 ELSE 0 END) as passed_modules,
                SUM(CASE WHEN sm.status = 'completed' AND sm.grade = 'F' THEN 1 ELSE 0 END) as failed_modules,
                SUM(CASE WHEN sm.status = 'registered' THEN 1 ELSE 0 END) as registered_modules,
                ROUND((s.total_credits_earned * 100.0 / p.total_credits), 2) as degree_progress_percent
            FROM students s
            JOIN programs p ON s.program_code = p.program_code
            LEFT JOIN student_modules sm ON s.username = sm.username
            WHERE s.enrollment_status = 'active'
            GROUP BY s.username, s.first_name, s.last_name, s.program_code, p.program_name, s.year_level, s.total_credits_earned, p.total_credits
            ORDER BY s.program_code, s.username
        ''')
        
        academic_overview = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'academic_overview': academic_overview
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/admin/student-academic-details/<student_id>')
@login_required
def admin_student_academic_details(student_id):
    if current_user.role != 'admin':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.*, p.program_name, p.total_credits as program_total_credits
            FROM students s
            JOIN programs p ON s.program_code = p.program_code
            WHERE s.username = ?
        ''', (student_id,))
        
        student_info = cursor.fetchone()
        if not student_info:
            return jsonify({'success': False, 'error': 'Student not found'})
        
        cursor.execute('''
            SELECT 
                sm.*,
                pm.credits as module_max_credits,
                pm.nqf_level,
                pm.department
            FROM student_modules sm
            LEFT JOIN program_modules pm ON sm.module_code = pm.module_code
            WHERE sm.username = ?
            ORDER BY sm.academic_year DESC, sm.semester, sm.module_code
        ''', (student_id,))
        
        modules = [dict(row) for row in cursor.fetchall()]
        
        completed_modules = [m for m in modules if m['status'] == 'completed']
        registered_modules = [m for m in modules if m['status'] == 'registered']
        failed_modules = [m for m in completed_modules if m['grade'] == 'F']
        passed_modules = [m for m in completed_modules if m['grade'] != 'F']
        
        grade_points = {
            'A': 4.0, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 
            'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0.0
        }
        
        total_points = 0
        graded_modules = 0
        
        for module in completed_modules:
            if module['grade'] in grade_points:
                total_points += grade_points[module['grade']]
                graded_modules += 1
        
        cumulative_gpa = round(total_points / graded_modules, 2) if graded_modules > 0 else 0.0
        
        yearly_performance = {}
        for module in modules:
            year = module['academic_year']
            if year not in yearly_performance:
                yearly_performance[year] = {
                    'modules': 0,
                    'credits_earned': 0,
                    'gpa': 0.0,
                    'completed': 0,
                    'failed': 0
                }
            
            yearly_performance[year]['modules'] += 1
            
            if module['status'] == 'completed':
                yearly_performance[year]['credits_earned'] += module.get('credits_earned', 0)
                yearly_performance[year]['completed'] += 1
                
                if module['grade'] == 'F':
                    yearly_performance[year]['failed'] += 1
                
                if module['grade'] in grade_points:
                    yearly_performance[year]['gpa'] += grade_points[module['grade']]
        
        for year, data in yearly_performance.items():
            graded_count = len([m for m in modules if m['academic_year'] == year and m['status'] == 'completed' and m['grade'] in grade_points])
            if graded_count > 0:
                data['gpa'] = round(data['gpa'] / graded_count, 2)
        
        academic_stats = {
            'total_modules': len(modules),
            'completed_modules': len(completed_modules),
            'registered_modules': len(registered_modules),
            'passed_modules': len(passed_modules),
            'failed_modules': len(failed_modules),
            'total_credits_earned': student_info['total_credits_earned'],
            'program_total_credits': student_info['program_total_credits'],
            'degree_progress_percent': round((student_info['total_credits_earned'] * 100.0 / student_info['program_total_credits']), 2),
            'cumulative_gpa': cumulative_gpa,
            'yearly_performance': yearly_performance
        }
        
        conn.close()
        
        return jsonify({
            'success': True,
            'student_info': dict(student_info),
            'academic_stats': academic_stats,
            'modules': modules
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/student/comprehensive-record')
@login_required
def get_comprehensive_academic_record():
    if current_user.role != 'student':
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT s.*, p.program_name, p.total_credits as program_total_credits
            FROM students s
            JOIN programs p ON s.program_code = p.program_code
            WHERE s.username = ?
        ''', (current_user.username,))
        
        student_info = cursor.fetchone()
        
        cursor.execute('''
            SELECT 
                sm.*,
                pm.credits as module_max_credits,
                pm.nqf_level,
                pm.department
            FROM student_modules sm
            LEFT JOIN program_modules pm ON sm.module_code = pm.module_code
            WHERE sm.username = ?
            ORDER BY sm.academic_year DESC, sm.semester, sm.module_code
        ''', (current_user.username,))
        
        modules = [dict(row) for row in cursor.fetchall()]
        
        completed_modules = [m for m in modules if m['status'] == 'completed']
        registered_modules = [m for m in modules if m['status'] == 'registered']
        failed_modules = [m for m in completed_modules if m['grade'] == 'F']
        passed_modules = [m for m in completed_modules if m['grade'] != 'F']
        
        grade_points = {
            'A': 4.0, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 
            'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0.0
        }
        
        total_points = 0
        graded_modules = 0
        
        for module in completed_modules:
            if module['grade'] in grade_points:
                total_points += grade_points[module['grade']]
                graded_modules += 1
        
        cumulative_gpa = round(total_points / graded_modules, 2) if graded_modules > 0 else 0.0
        
        yearly_performance = {}
        for module in modules:
            year = module['academic_year']
            if year not in yearly_performance:
                yearly_performance[year] = {
                    'modules': 0,
                    'credits_earned': 0,
                    'gpa': 0.0,
                    'completed': 0,
                    'failed': 0
                }
            
            yearly_performance[year]['modules'] += 1
            
            if module['status'] == 'completed':
                yearly_performance[year]['credits_earned'] += module.get('credits_earned', 0)
                yearly_performance[year]['completed'] += 1
                
                if module['grade'] == 'F':
                    yearly_performance[year]['failed'] += 1
                
                if module['grade'] in grade_points:
                    yearly_performance[year]['gpa'] += grade_points[module['grade']]
        
        for year, data in yearly_performance.items():
            graded_count = len([m for m in modules if m['academic_year'] == year and m['status'] == 'completed' and m['grade'] in grade_points])
            if graded_count > 0:
                data['gpa'] = round(data['gpa'] / graded_count, 2)
        
        academic_stats = {
            'total_modules': len(modules),
            'completed_modules': len(completed_modules),
            'registered_modules': len(registered_modules),
            'passed_modules': len(passed_modules),
            'failed_modules': len(failed_modules),
            'total_credits_earned': student_info['total_credits_earned'],
            'program_total_credits': student_info['program_total_credits'],
            'degree_progress_percent': round((student_info['total_credits_earned'] * 100.0 / student_info['program_total_credits']), 2),
            'cumulative_gpa': cumulative_gpa,
            'yearly_performance': yearly_performance
        }
        
        conn.close()
        
        return jsonify({
            'success': True,
            'student_info': dict(student_info),
            'academic_stats': academic_stats,
            'modules': modules
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# ========== DEBUG ROUTES ==========

@app.route('/debug/database-structure')
def debug_database_structure():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(modification_requests)")
        table_info = cursor.fetchall()
        table_structure = [dict(row) for row in table_info]
        
        cursor.execute("SELECT * FROM modification_requests ORDER BY created_at DESC LIMIT 5")
        recent_requests = cursor.fetchall()
        recent_requests_list = [dict(row) for row in recent_requests]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'table_structure': table_structure,
            'recent_requests': recent_requests_list
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/debug/lecturer-setup')
def debug_lecturer_setup():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT username, last_name FROM lecturers LIMIT 5")
        lecturers = cursor.fetchall()
        lecturers_list = [dict(l) for l in lecturers]
        
        cursor.execute('''
            SELECT l.username, l.last_name, ma.module_code, pm.module_name
            FROM lecturers l
            JOIN module_assignments ma ON l.username = ma.lecturer_username
            JOIN program_modules pm ON ma.module_code = pm.module_code
            LIMIT 10
        ''')
        assignments = cursor.fetchall()
        assignments_list = [dict(a) for a in assignments]
        
        cursor.execute("SELECT * FROM modification_requests")
        requests = cursor.fetchall()
        requests_list = [dict(r) for r in requests]
        
        cursor.execute('''
            SELECT ma.module_code, pm.module_name
            FROM module_assignments ma
            JOIN program_modules pm ON ma.module_code = pm.module_code
            WHERE ma.lecturer_username = 'lecturer.cs1'
        ''')
        lecturer_cs1_modules = cursor.fetchall()
        lecturer_cs1_modules_list = [dict(m) for m in lecturer_cs1_modules]
        
        conn.close()
        
        return jsonify({
            'success': True,
            'lecturers': lecturers_list,
            'assignments': assignments_list,
            'requests': requests_list,
            'lecturer_cs1_modules': lecturer_cs1_modules_list
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/debug/check-requests-table')
def debug_check_requests_table():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='modification_requests'")
        table_exists = cursor.fetchone()
        
        if not table_exists:
            return jsonify({'error': 'modification_requests table does not exist'})
        
        cursor.execute("PRAGMA table_info(modification_requests)")
        columns = cursor.fetchall()
        column_info = [dict(col) for col in columns]
        
        cursor.execute("SELECT COUNT(*) as count FROM modification_requests")
        request_count = cursor.fetchone()['count']
        
        cursor.execute("SELECT * FROM modification_requests ORDER BY created_at DESC LIMIT 5")
        recent_requests = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'table_exists': True,
            'columns': column_info,
            'total_requests': request_count,
            'recent_requests': recent_requests
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/debug/student-columns')
def debug_student_columns():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("PRAGMA table_info(students)")
        columns = cursor.fetchall()
        column_info = [dict(col) for col in columns]
        
        cursor.execute("SELECT * FROM students LIMIT 1")
        sample_student = dict(cursor.fetchone()) if cursor.fetchone() else None
        
        conn.close()
        
        return jsonify({
            'success': True,
            'columns': column_info,
            'sample_student': sample_student
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/student/add-module', methods=['POST'])
@login_required
def student_add_module():
    # only students
    if getattr(current_user, 'role', None) != 'student':
        return jsonify({'success': False, 'message': 'Access denied'}), 403

    data = request.get_json(silent=True) or request.form
    module_code = data.get('module_code')
    module_name = data.get('module_name')
    semester = data.get('semester', '2')
    academic_year = int(data.get('academic_year', 2025))

    if not module_code:
        return jsonify({'success': False, 'message': 'module_code required'}), 400

    try:
        conn = get_db_connection()
        cur = conn.cursor()

        # validate student exists
        cur.execute('SELECT 1 FROM students WHERE username = ?', (current_user.username,))
        if not cur.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': 'Student account not found'}), 404

        # validate module exists in program_modules
        cur.execute('SELECT module_name FROM program_modules WHERE module_code = ?', (module_code,))
        pm = cur.fetchone()
        if not pm:
            conn.close()
            return jsonify({'success': False, 'message': 'Module not found'}), 404

        # prevent duplicate registration for same year/semester
        cur.execute('''
            SELECT 1 FROM student_modules
            WHERE username = ? AND module_code = ? AND academic_year = ? AND semester = ?
        ''', (current_user.username, module_code, academic_year, semester))
        if cur.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': 'Module already added for that year/semester'}), 409

        # insert
        cur.execute('''
            INSERT INTO student_modules (username, module_code, module_name, semester, academic_year, status, added_at)
            VALUES (?, ?, ?, ?, ?, 'registered', datetime('now'))
        ''', (current_user.username, module_code, module_name or pm['module_name'], semester, academic_year))
        conn.commit()
        conn.close()
        return jsonify({'success': True, 'message': 'Module added'}), 201

    except Exception as e:
        try:
            conn.rollback()
        except:
            pass
        print('student_add_module error:', e)
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/test-connection')
def test_connection():
    """Test database and basic connectivity"""
    try:
        # Test database connection
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        db_test = cursor.fetchone()
        conn.close()
        
        # Test modification_requests table exists
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='modification_requests'")
        table_exists = cursor.fetchone()
        conn.close()
        
        return jsonify({
            'success': True,
            'database_connection': 'OK',
            'modification_requests_table': 'Exists' if table_exists else 'Missing',
            'current_user_authenticated': current_user.is_authenticated if hasattr(current_user, 'is_authenticated') else False
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

if __name__ == '__main__':
    if not os.path.exists('data'):
        os.makedirs('data')
    if not os.path.exists('database.db'):
        sql_path = 'university_database.sql'
        if os.path.exists(sql_path):
            try:
                print(f"Database not found - creating from {sql_path}...")
                with open(sql_path, 'r', encoding='utf-8') as f:
                    sql = f.read()
                conn = sqlite3.connect('database.db')
                cur = conn.cursor()
                cur.executescript(sql)
                conn.commit()
                conn.close()
                print('database.db created from SQL script')
            except Exception as e:
                print('Failed to create database from SQL:', e)
                try:
                    sqlite3.connect('database.db').close()
                    print('Created empty database.db (fallback)')
                except Exception as e2:
                    print('Failed to create empty database file:', e2)
        else:
            try:
                sqlite3.connect('database.db').close()
                print('Created empty database.db')
            except Exception as e:
                print('Failed to create empty database file:', e)

    app.run(debug=True, host='0.0.0.0', port=5000)